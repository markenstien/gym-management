<?php

	define('PATH_UPLOAD' , BASE_DIR.DS.'public/uploads');
	
	define('GET_PATH_UPLOAD' , URL.DS.'public/uploads');

	define('PATH_PUBLIC' ,URL.DS.'public');

	define('PATH_TMP' , PATH_PUBLIC.DS.'tmp');

	define('PATH_VENDOR' , BASE_DIR.DS.'public/vendor');